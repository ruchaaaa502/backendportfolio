const express = require('express');
const router = express.Router();
const Contact = require('../models/contact'); // Adjust the path if necessary

// POST route to handle contact form submission
router.post('/', async (req, res) => {
  const { name, email, message } = req.body;

  // Create a new contact instance
  const newContact = new Contact({ name, email, message });

  try {
    // Save the contact to the database
    await newContact.save();
    res.status(201).json({ message: 'Contact saved successfully' });
  } catch (error) {
    res.status(400).json({ error: 'Error saving contact' });
  }
});

module.exports = router;
