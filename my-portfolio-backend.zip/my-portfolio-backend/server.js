const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const contactRoutes = require('./routes/contact');

const app = express();
const port = process.env.PORT || 5000;

// Middleware setup
app.use(cors());
app.use(bodyParser.json());

// MongoDB connection
mongoose.connect('mongodb+srv://nakilrucha09:Z6U3YmGptvQtKMI1@test.bp8codp.mongodb.net/test', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const connection = mongoose.connection;
connection.once('open', () => {
  console.log('MongoDB database connection established successfully');
});

// Routes setup
app.use('/api/contact', contactRoutes);

// Server start
app.listen(port, () => {
  console.log(`Server is running on port: ${port}`);
});
